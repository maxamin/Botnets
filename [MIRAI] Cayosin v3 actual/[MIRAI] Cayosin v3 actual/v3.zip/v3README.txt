Cayosin v3 - Cut Out Their Hearts


Upon connection to your server, the terminal will remain black. Simply type "login" and press enter. You will be sent to the login screen.
If you have a token to redeem, instead of typing "login" You will type "register [token]" Ex: register EHSOLG
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
The Cayosin Bot features unique RHex STD and RHex HTTP attacks. Meaning that the Hex Strings are randomly selected.
Cayosin also contains a custom rTCP method for qBot, comparable to XMAS. As well as a VSE method. 
Then the standard UDP, TCP, and CNC floods. 
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
Pathways:

Version 3 runs different Pathways for different Commands. Most sources send everything anyone types on the bot socket. Meaning you could 
connect to the bot port through Putty and sit there, and see everything anyone types. Not secure.

With v3, each input must be prefaced with a Pathway Trigger (Except for the Help Commands)
Triggers are: < for Chat | * for bots | . for ServerSide
To input through the Chat Pathway [<] - Ex: < Sup Fuckers
To input through the Bot Pathway [*] - Ex: * . UDP etc
To input through the SS Pathway [.] for tools etc - Ex: . iplookup 8.8.8.8 | All Admin Cmds, Tools and Features run on this Path
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
New Account Stats:

Accounts now have a Max Bot Control, Max Flood Time, and a Cooldown.
When you add a user you'll be prompted for each of these. You can choose between 1 and 999999. To make a stat unlimited, use -1.
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
New Token System:

The Token System is now only used for selling Monthly or Yearly Spots. If you aren't selling for a month or year, just use . adduser
When selling a Monthly or Yearly spot, you'll . GENTOKEN
You will then preset the stats for that Token. Once completed, and the Token is Generated, You will give the Hosting, Port, and Token to the customer. 
Upon connection to the server, instead of typing "login" Advise them to type "register [token]" Ex: register TRYDJ
The system will check if the Token has been claimed. If not, they will have the option to claim it. When they accept, they'll be prompted
to choose a Username and Password. The system will automatically move their chosen login over to the database, along with the stats that
were preset with the token they redeemed. They'll reopen the terminal, type "login" and log in like normal.

After that, that token is useless, and you'll never need it again.
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
Chat:
Upon Connection, the Chat will now be disabled. To opt into the chat, type ". CHAT ON"
Admins have the ability to force all online users into chat with ". UNMUTE"
We also now have a Direct Message feature. When you . MSG you'll be prompted for the user and message you'd like to send.
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
ADMINS: 

The new Admin Cmds are self explanatory. We have a Blacklist.
When an admin checks online users, you'll see regular customers IPv4 next to their Username. (Admin IPs will Not Show)
This is how you'll ban/unban.
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
IP Lookup reaches out through an API to grab address info. If for some reason you recompile your bot, or clear html, you'll need to 
reload the php file to your server. If you bought a build or lifetime builds from me, just shoot me a message and I'll reload it for you.
---------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------
*Disclaimers* Version 3 is NOT modified of version 1 or 2. This is completely brand new, coded from complete scratch by Snickers.
The credits for the RHex methods go to Studo.*